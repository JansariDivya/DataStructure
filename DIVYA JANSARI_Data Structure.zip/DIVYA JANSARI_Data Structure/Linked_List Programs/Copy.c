#include <stdio.h>
#include <stdlib.h>

struct LinkNode
{
	// Define useful field of LinkNode
	int data;
	struct LinkNode * next;
}LinkNode;

struct LinkNode* getLinkNode(int data, struct LinkNode * top)
{
	
	struct LinkNode * ref = (struct LinkNode * ) malloc(sizeof(LinkNode));
	if (ref == NULL)
	{
		// Failed to create memory 
		return NULL;
	}
	ref->data = data;
	ref->next = top;
	return ref;
}
struct SingleLL
{
	
	struct LinkNode * head;
}SingleLL;

struct SingleLL * getSingleLL()
{
	// Create dynamic memory of SingleLL
	struct SingleLL * ref = (struct SingleLL * ) malloc(sizeof(SingleLL));
	if (ref == NULL)
	{
		// Failed to create memory 
		return NULL;
	}
	ref->head = NULL;
	return ref;
}
// Adding new node at beginning of linked list
void addNode(struct SingleLL * ref, int data)
{
	// Create new node
	// And add at front position
	ref->head = getLinkNode(data, ref->head);
}
// Display linked list element
void display(struct SingleLL * ref)
{
	if (ref->head == NULL)
	{
		return;
	}
	struct LinkNode * temp = ref->head;
	// iterating linked list elements
	while (temp != NULL)
	{
		printf(" %d ->", temp->data);
		// Visit to next node
		temp = temp->next;
	}
	printf(" NULL\n");
}
struct SingleLL * cloneList(struct SingleLL * ref)
{
	
	struct SingleLL * result = getSingleLL();
	
	struct LinkNode * node = ref->head;
    struct LinkNode * tail = NULL;
	
	while (node != NULL)
	{
		if (result->head == NULL)
		{
			// Add first node
			result->head = getLinkNode(node->data, NULL);
			// Get last node
			tail = result->head;
		}
		else
		{
			// Add node at the end position
			tail->next = getLinkNode(node->data, NULL);
			// Visit to new last node
			tail = tail->next;
		}
		// Visit to next node
		node = node->next;
	}
	return result;
}
int main()
{
	struct SingleLL * sll = getSingleLL();
	
	addNode(sll, 7);
	addNode(sll, 11);
	addNode(sll, 4);
	addNode(sll, 9);
	addNode(sll, 20);
	addNode(sll, 1);
	printf(" Actual linked list \n");
	display(sll);
	struct SingleLL * copy = cloneList(sll);
	
	printf("\n Clone linked list \n");
	display(copy);
	return (0);
}
