#include <stdio.h>
#include <stdlib.h>

struct Node
{
	int data;
	struct Node* next;
};

//  print a given linked list
void printList(struct Node* head)
{
	struct Node* ptr = head;
	while (ptr)
	{
		printf("%d �> ", ptr->data);
		ptr = ptr->next;
	}
	printf("NULL");
}

// Helper function to insert a new node at the beginning of the linked list
void push(struct Node** head, int data)
{
	struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
	newNode->data = data;
	newNode->next = *head;
	*head = newNode;
}


struct Node* newNode(int data)
{
	struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
	newNode->data = data;
	newNode->next = NULL;
	return newNode;
}

// Function to insert a given node at its correct sorted position 
void sortedInsert(struct Node** head, struct Node* newNode)
{
	// special case for the head end
	if (*head == NULL || (*head)->data >= newNode->data)
	{
		newNode->next = *head;
		*head = newNode;
		return;
	}

	struct Node* current = *head;
	while (current->next != NULL && current->next->data < newNode->data) {
		current = current->next;
	}

	newNode->next = current->next;
	current->next = newNode;
}

int main(void)
{


	// points to the head node of the linked list
	struct Node* head = NULL;

	// construct a linked list

        sortedInsert(&head, newNode(10));
	sortedInsert(&head, newNode(5));
	sortedInsert(&head, newNode(9));
	sortedInsert(&head, newNode(1));

	// print linked list
        printf("Elements after SortedInsert\n");
	printList(head);

	return 0;
}