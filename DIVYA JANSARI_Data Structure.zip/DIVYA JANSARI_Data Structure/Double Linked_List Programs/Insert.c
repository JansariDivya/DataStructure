#include <stdio.h>
#include <stdlib.h>

struct node {
int data;
struct node *next;
struct node *prev;
}node;

struct linked_list {
struct node *head;
}linked_list;

//to make new node
struct node* new_node(int data) {
struct node *z;
z = malloc(sizeof(struct node));
z->data = data;
z->next = NULL;
z->prev = NULL;

return z;
}

//to make a new linked list

struct linked_list* new_linked_list(int data) {
struct node *a; 
a = new_node(data);

struct linked_list *l = malloc(sizeof(linked_list)); 
l->head = a;

return l;
}

void traversal(struct linked_list *l) {
struct node *temp = l->head; 

while(temp != NULL) { 
  printf("%d\t", temp->data);
  temp = temp->next;
}

printf("\n");
}

//new node before head
void insert_at_front(struct linked_list *l, struct node *n) {
n->next = l->head;
l->head->prev = n;
l->head = n;
}

//insert new node at last
void insert_at_tail(struct linked_list *l, struct node *n) {
struct node *temp = l->head;

while(temp->next != NULL) {
  temp = temp->next;
}

temp->next = n;
n->prev = temp;
}

//function to insert a node after a node
void insert_after(struct node *n, struct node *a) {
n->next = a->next;
a->next->prev = n;
a->next = n;
n->prev = a;
}



int main() {

struct linked_list *l = new_linked_list(10);

struct node *a, *b, *c; //new nodes to insert in linekd list
a = new_node(20);
b = new_node(50);
c = new_node(60);

l->head->next = a;
a->next = b;
b->next = c;

struct node *z;

z = new_node(0);

insert_at_front(l, z);

z = new_node(2);
insert_at_front(l, z);

z = new_node(100);
insert_at_tail(l, z);

z = new_node(30);

insert_after(z, a);

z = new_node(40);
insert_after(z, a->next);

z = new_node(500);
insert_after(z, a->next->next);

printf("Elements in the list\n");
traversal(l);

return 0;
}
