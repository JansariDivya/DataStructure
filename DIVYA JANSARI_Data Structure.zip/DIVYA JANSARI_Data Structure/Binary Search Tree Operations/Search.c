// Search in Binary Search Tree

#include <stdio.h>
#include <stdlib.h>

struct node {
  int data;
  struct node *right_child;
  struct node *left_child;
};


struct node* new_node(int x)
{
    struct node *p;
    p = malloc(sizeof(struct node));
    p->data = x;
    p->left_child = NULL;
    p->right_child = NULL;

    return p;
}

struct node* insert(struct node *root, int x)
{
    
    if(root==NULL)
        return new_node(x);
    else if(x>root->data) 
        root->right_child = insert(root->right_child, x);
    else 
        root->left_child = insert(root->left_child,x);
    return root;
}

struct node* search(struct node *root, int x)
{
    
    if(root==NULL || root->data==x)
        return root;
    else if(x>root->data) 
        return search(root->right_child, x);
    else 
        return search(root->left_child,x);
        
    
}

void preorder(struct node *root)
{
    if(root!=NULL) 
    {
        printf(" %d ", root->data); 
        preorder(root->left_child);
        preorder(root->right_child);
    }
}


int main() {
    
    
    
    int x;
    struct node *root;
    root = new_node(50);
    insert(root,25);
    insert(root,75);
    insert(root,22);
    insert(root,40);
    insert(root,60);
    insert(root,80);
    insert(root,90);
    insert(root,15);
    insert(root,30);
   
   printf("Elements in the linked list\n");
   preorder(root);
   printf("\n");

   printf("Which element to search?");
    scanf("%d",&x);
    
     if(search(root,x))
     printf("Element Found");
     else
     printf("Element Not Found");

return(0);

}
