#include <stdio.h>
#include <stdlib.h>


struct node
{
    int data; 
    struct node *right_child; // right child
    struct node *left_child; // left child
};

struct node* new_node(int data)
{
    struct node *p; 
    p = malloc(sizeof(struct node)); 
    p->data = data; 
    p->left_child = NULL; 
    p->right_child = NULL;

    return(p); 
}

void preorder(struct node *root)
{
    if(root!=NULL) // checking if the root is not null
    {
        printf(" %d ", root->data); // printing data at root
        preorder(root->left_child); // visiting left child
        preorder(root->right_child); // visiting right child
    }
}


int main()
{
    struct node *root; //new structure
    root = new_node(1); // making a new node
   
    root->left_child = new_node(2); //left child of root


    root->right_child = new_node(3); //right child of root



    root->left_child->left_child = new_node(4); // new node



    root->left_child->right_child = new_node(5); // new node

   

    printf("PreOrder\n");
    preorder(root);
    printf("\n");

    return 0;
}